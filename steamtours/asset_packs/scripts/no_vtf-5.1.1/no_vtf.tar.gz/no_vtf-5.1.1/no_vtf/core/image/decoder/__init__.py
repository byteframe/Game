# SPDX-FileCopyrightText: b5327157 <b5327157@protonmail.com>
#
# SPDX-License-Identifier: LGPL-3.0-or-later

from .decoder import ImageDecoder

__all__ = [
    "ImageDecoder",
]
